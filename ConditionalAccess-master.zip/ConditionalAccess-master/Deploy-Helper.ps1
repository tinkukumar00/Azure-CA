.\Deploy-Policies.ps1 `
-Prefix "ZT" `
-Ring "ALL" `
-PoliciesFolder "C:\AF\Repos\ConditionalAccess\PolicySets\Category structure for AADP1 and AADP2 mixture"